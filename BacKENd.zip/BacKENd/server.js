// // test.js
// const express = require("express");
// const mongoose = require("mongoose");

// const app = express();

// mongoose.connect("mongodb://localhost:27017/test", {
//   useNewUrlParser: true,
//   useUnifiedTopology: true,
// })
//   .then(() => console.log("DB connected"))
//   .catch(err => console.error("DB connection error:", err));

// app.get("/", (req, res) => {
//   res.send("Hello World!");
// });

// const port = 3000;
// app.listen(port, () => {
//   console.log(`Server is listening on port ${port}`);
// });
//-----------the upper code for db connect to the server--------------------------------
const express = require("express");
const mongoose = require("mongoose");
const app = express();
app.use(express.json());

// Connecting to MongoDB
mongoose
  .connect("mongodb://localhost:27017/Studens-info", {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(() => {
    console.log("DB connected!");
  })
  .catch((err) => {
    console.error("DB connection error:", err);
  });

// Creating the schema
const InfosSchema = new mongoose.Schema({
  name: {
    require: true,
    type: String,
  },
  place: {
    require: true,
    type: String,
  },
  age: {
    type: Number,
  },
  DOB: {
    require: true,
    type: String,
  },
});

// Creating model
const InfosModel = mongoose.model("Data", InfosSchema);

// Create a new todo item
app.post("/new", async (req, res) => {
  const { name, place, age, DOB } = req.body;
  try {
    const newInfo = new InfosModel({ name, place, age, DOB });
    await newInfo.save();
    res.status(201).json(newInfo);
  } catch (error) {
    console.error("Create Info error:", error);
    res.status(500).json({ message: error.message });
  }
});

// Get all items
app.get("/new", async (req, res) => {
  try {
    const infos = await InfosModel.find();
    res.json(infos);
  } catch (error) {
    console.error("Get Infos error:", error);
    res.status(500).json({ message: error.message });
  }
});

// Delete an item by ID
app.delete("/new/:id", async (req, res) => {
  try {
    const id = req.params.id;
    const result = await InfosModel.findByIdAndDelete(id);
    if (result) {
      res.status(204).end();
    } else {
      res.status(404).json({ message: "Info not found" });
    }
  } catch (error) {
    console.error("Delete Info error:", error);
    res.status(500).json({ message: error.message });
  }
});

// Update an item by ID
app.patch("/new/:id", async (req, res) => {
  try {
    const id = req.params.id;
    const updates = req.body;
    const result = await InfosModel.findByIdAndUpdate(id, updates, {
      new: true,
      runValidators: true,
    });
    if (result) {
      res.json(result);
    } else {
      res.status(404).json({ message: "Info not found" });
    }
  } catch (error) {
    console.error("Update Info error:", error);
    res.status(500).json({ message: error.message });
  }
});

const port = 3000;
app.listen(port, () => {
  console.log(`Server is listening on port ${port}`);
});
